# TeacherSE

#Synopsis

Teacher is an easy to use kids Android application targeted towards the Nexus 7 tablet. The user is allowed to choose from three difficulty levels, which then allow them to interact with various mini games for spelling, grammar, and math.

#Motivation

This application is aimed towards children in order to provide them with an easy to use and fun medium to learn valuable skills.

#Installation

Download the apk file onto an Android device (prefferably with Lolliop OS) or download the code into Android Studio.

#Tests

Testing was done through user interaction/feedback and some simple unit tests.
